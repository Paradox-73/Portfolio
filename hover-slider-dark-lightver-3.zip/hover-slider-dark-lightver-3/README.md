# Hover slider (dark/light) - ver 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/MRbJWW](https://codepen.io/ig_design/pen/MRbJWW).

