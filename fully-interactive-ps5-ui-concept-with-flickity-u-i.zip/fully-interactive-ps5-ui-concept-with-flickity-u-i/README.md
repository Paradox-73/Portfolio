# Fully Interactive PS5 UI Concept with Flickity (U.I.)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Rayzooo/pen/MWbKWqQ](https://codepen.io/Rayzooo/pen/MWbKWqQ).

Concept by Joshua Oluwagbemiga on Dribbble: https://dribbble.com/shots/11897442-PlayStation-5-Concept-UI-InVision-Studio